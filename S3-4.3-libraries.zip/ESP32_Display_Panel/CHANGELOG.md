# ChangeLog

## v0.0.1 - 2023-09-20

### Enhancements:

* Supports various Espressif official development boards
* Supports custom boards
* Supports multiple types of drivers, including **Bus**, **LCD**, **Touch**, **Backlight**

## v0.0.2 - 2023-11-09

### Enhancements:

* Move extra boards configuration into panel
* Update all README.md files
* Add Squareline porting examples
